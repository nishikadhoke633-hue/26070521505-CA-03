import { useState } from "react";
import "./App.css";

function App() {
  const [sending, setSending] = useState(false);

  const handleContactSubmit = async (e) => {
    e.preventDefault();

    const form = e.currentTarget;
    const formData = new FormData(form);

    const contactData = {
      name: formData.get("name"),
      email: formData.get("email"),
      subject: formData.get("subject"),
      message: formData.get("message"),
    };

    try {
      setSending(true);

      const response = await fetch(
        "http://localhost:5000/api/contact",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(contactData),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(
          result.message || "Message could not be sent"
        );
      }

      alert("Message sent successfully!");
      form.reset();
    } catch (error) {
      console.error("Contact form error:", error);
      alert(
        "Message send nahi hua. Backend aur API route check karein."
      );
    } finally {
      setSending(false);
    }
  };

  const skills = [
    "HTML",
    "CSS",
    "JavaScript",
    "React.js",
    "Node.js",
    "Express.js",
    "MongoDB",
    "GitHub",
  ];

  return (
    <div className="portfolio">
      <nav className="navbar">
        <a className="logo" href="#home">
          NISHIKA<span>.</span>
        </a>

        <div className="navlinks">
          <a href="#home">Home</a>
          <a href="#about">About</a>
          <a href="#education">Education</a>
          <a href="#skills">Skills</a>
          <a href="#projects">Projects</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      <main>
        {/* HOME */}
        <section id="home" className="hero">
          <div className="hero-content">
            <p className="tag">
              B.TECH CSE STUDENT · SIT NAGPUR
            </p>

            <h1>
              Hi, I'm <span>Nishika Dhoke</span>
            </h1>

            <h2>Future Software Developer</h2>

            <p>
              I love technology, creative ideas and building
              modern websites. I am continuously learning new
              skills to become a better developer.
            </p>

            <div className="hero-buttons">
              <a className="btn" href="#projects">
                Explore My Work ↗️
              </a>

              <a className="btn" href="#contact">
                Contact Me
              </a>
            </div>
          </div>

          <div className="profile-frame">
            <img
              src="/images/profile.jpg"
              alt="Nishika Dhoke"
              className="profile-photo"
            />
            <div className="profile-caption">
              <span className="status-dot"></span>
              CSE Student · Aspiring Developer
            </div>
          </div>
        </section> 
        {/* ABOUT */}
        <section id="about" className="section">
          <p className="tag">GET TO KNOW ME</p>
          <h2>About Me</h2>

          <p>
            I am a Computer Science Engineering student at
            Symbiosis Institute of Technology, Nagpur. I am
            interested in web development, problem-solving
            and learning modern technologies.
          </p>

          <p>
            My goal is to develop useful, user-friendly
            applications and grow as a software developer.
          </p>
        </section>

        {/* EDUCATION */}
        <section id="education" className="section">
          <p className="tag">MY LEARNING JOURNEY</p>
          <h2>Education</h2>

          <article className="project-card">
            <p>UNDERGRADUATE</p>
            <h3>B.Tech — Computer Science Engineering</h3>
            <p>
              Symbiosis Institute of Technology, Nagpur
            </p>
            <p>Currently pursuing</p>
          </article>

          <article className="project-card">
            <p>DIPLOMA</p>
            <h3>Engineering Diploma</h3>
            <p>NIT Polytechnic, Nagpur</p>
          </article>

          <article className="project-card">
            <p>SCHOOL</p>
            <h3>Secondary Education</h3>
            <p>Jindal Vidya Mandir, Kalmeshwar</p>
          </article>
        </section>

        {/* SKILLS */}
        <section id="skills" className="section">
          <p className="tag">WHAT I AM LEARNING</p>
          <h2>Technical Skills</h2>

          <div className="skills">
            {skills.map((skill) => (
              <span key={skill} className="skill-item">
                {skill}
              </span>
            ))}
          </div>
        </section>

        {/* PROJECTS */}
        <section id="projects" className="section">
          <p className="tag">SELECTED WORK</p>
          <h2>My Projects</h2>

          <article className="project-card">
            <p>01 / FLEXI PROJECT</p>
            <h3>Student Personal Portfolio</h3>
            <p>
              A full-stack portfolio website built with
              React.js, Node.js, Express.js and MongoDB.
              It includes a contact form that saves messages
              in the database.
            </p>
            <span className="project-tech">
              React · Node.js · MongoDB
            </span>
          </article>

          <article className="project-card">
            <p>02 / STUDENT PROJECT CONCEPT</p>
            <h3>Student Marks Prediction</h3>
            <p>
              A student project concept focused on analysing
              academic performance and predicting marks.
            </p>
            <span className="project-tech">
              Project concept
            </span>
          </article>
        </section>

        {/* CONTACT */}
        <section id="contact" className="section">
          <p className="tag">LET'S CONNECT</p>
          <h2>Contact Me</h2>

          <p>
            Have a question or want to work together?
            Send me a message using the form below.
          </p>

          <form
            className="contact-form"
            onSubmit={handleContactSubmit}
          >
            <label>
              Name
              <input
                name="name"
                type="text"
                placeholder="Enter your name"
                required
              />
            </label>

            <label>
              Email
              <input
                name="email"
                type="email"
                placeholder="Enter your email"
                required
              />
            </label>

            <label>
              Subject
              <input
                name="subject"
                type="text"
                placeholder="Message subject"
                required
              />
            </label>

            <label>
              Message
              <textarea
                name="message"
                placeholder="Write your message here"
                rows="5"
                required
              />
            </label>

            <button type="submit" disabled={sending}>
              {sending ? "Sending..." : "Send Message"}
            </button>
          </form>
        </section>
      </main>

      <footer>
        <p>© 2026 Nishika Dhoke · FLEXI Project</p>
        <a href="#home">Back to Top ↑</a>
      </footer>
    </div>
  );
}

export default App;